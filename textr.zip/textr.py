a=input("entar your textyour text: ")
x=int(input("entar your velu: "))
for i in range(x):
	print(a)